package com.example.student.myapplication;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable ad;
    boolean mystate=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView iv = (ImageView) findViewById(R.id.imageView4);
        iv.setBackgroundResource(R.drawable.ani);
        ad = (AnimationDrawable) iv.getBackground();


        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mystate){
                    ad.stop();
                    mystate=false;
                }else{
                    ad.start();
                    mystate=true;

                    ImageView spaceshipImage =(ImageView)findViewById(R.id.imageView5);
                    Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.translate);
                    spaceshipImage.startAnimation(hyperspaceJumpAnimation);
                }

            }


        });
    }


}